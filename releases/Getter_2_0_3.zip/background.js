var MAX_CONCURRENT_DOWNLOADS = 5;

var numDownloading = 0;
var numFinished = 0;
var downloadIds = [];
var queue = [];
var n = 0;

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.message == "getStats") {
            sendStats();
        }
        if (request.message == "addToQueue") {
            queue = queue.concat(request.urls);
            processQueue();
        }
        if (request.message == "clearDownloads") {
            numDownloading = 0;
            numFinished = 0;
            n = 0;
            downloadIds = [];
            queue = [];
            sendStats();
        }
    }
);

function sendStats() {
    chrome.runtime.sendMessage({ "message": "stats", "numDownloading": numDownloading, "numQueued": queue.length, "numFinished": numFinished });
}

function timestamp() {
    var date = new Date();
    return date.getFullYear().toString() + date.getMonth().toString() + date.getDate().toString() + date.getHours().toString() + date.getMinutes().toString() + date.getSeconds().toString() + date.getMilliseconds().toString();
}

function extension(filename) {
    var idx = filename.lastIndexOf('.');
    return (idx < 1) ? "" : filename.substr(idx + 1);
}

function processQueue() {
    while (queue.length > 0 && numDownloading < MAX_CONCURRENT_DOWNLOADS) {
        var url = queue.pop();
        var filename = timestamp() + "-" + n.toString() + "." + extension(url);
        numDownloading++;
        n++;
        chrome.downloads.download({ "url": url, "filename": filename }, function (downloadId) {
            downloadIds.push(downloadId);
        });
    }
    sendStats();
}

chrome.downloads.onChanged.addListener(function (downloadDelta) {
    console.log(downloadDelta);
    if (downloadIds.indexOf(downloadDelta.id) >= 0) {
        if (downloadDelta.state != undefined && downloadDelta.state.current != "in_progress") {
            downloadIds.splice(downloadIds.indexOf(downloadDelta.id), 1);
            numDownloading--;
            numFinished++;
            processQueue();
        }
    }
    sendStats();
});
